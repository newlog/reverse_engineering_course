#include <stdio.h>
#include <string.h>

static int call(const char *name) {
	char myname[10];
	if (strlen (name) < sizeof (myname)) {
		strcpy (myname, name);
		printf ("Your name is %s\n", myname);
	} else {
		printf ("This can't be your name. It's too long\n");
		return 1;
	}
	return 0;
}

main(int argc, char **argv) {
	if (argc > 1) {
		call(argv[1]);
	}
	return 0;
}
