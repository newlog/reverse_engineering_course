package main

import "net"
import "golang.org/x/net/netutil"
import "net/http"
import "log"

func main() {
	connectionCount := 3

	println("nc localhost 8000 &")
	println("nc localhost 8000 &")
	println("nc localhost 8000 &")
	println("curl localhost:8000")

	l, err := net.Listen("tcp", ":8000")

	if err != nil {
		log.Fatalf("Listen: %v", err)
	}

	defer l.Close()

	l = netutil.LimitListener(l, connectionCount)

	log.Fatal(http.Serve(l, nil))
}
