#include <stdio.h>
#include <stdlib.h>
int main() {
	char *foo = strdup ("heap");
	free (foo);
	strcpy (foo, "foo");
	printf ("%s\n", foo);
	return 0;
}
