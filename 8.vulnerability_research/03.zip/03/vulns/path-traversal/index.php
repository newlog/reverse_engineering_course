<?
	$path = $_GET["page"];
	if (!$path) {
		$path = "Makefile";
	}
	if ($path[0] == '/') {
		print("Invalid path. Incident will be reported");
	} else if ($path) {
		$path = str_replace("..", ".", $path);
		print ($path);
		$fd = fopen($path, "r");
		if ($fd) {
			$res = fread($fd, 1024);
			print($res);
			fclose($fd);
		}
	}
?>
