#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
	char *foo = strdup ("heap");
	strcpy (foo, "foobarcow");
	printf ("%s\n", foo);
	free (foo);
	return 0;
}
