static int call(const char *name) {
	char myname[10];
	strcpy (myname, name);
	printf ("Your name is %s\n", myname);
	return 0;
}

main(int argc, char **argv) {
	if (argc > 1) {
		call(argv[1]);
	}
}
