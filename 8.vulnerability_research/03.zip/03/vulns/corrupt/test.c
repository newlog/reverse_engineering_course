#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static int call(const char *name, const char *surname) {
	char myname[10];
	char mysurname[10];
	strcpy (myname, name);
	strcpy (mysurname, surname);
	printf ("Your name is %s and %s\n", myname, surname);
	return 0;
}

int main(int argc, char **argv) {
	if (argc > 2) {
		call (argv[1], argv[2]);
	}
	return 0;
}
