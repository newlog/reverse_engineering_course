int main(int argc, char **argv) {
	return strcpy (&argc, argv[1]);
}
